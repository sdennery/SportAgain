
<?php   session_start();    
        session_destroy();
?>

<?php  include "../Vue/header.php"; ?>



<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="">
    </head>
    
    <body> Vous êtes deconnecté
		
           <?php include'../Vue/footer.php' ?>
    </body>
</html>


