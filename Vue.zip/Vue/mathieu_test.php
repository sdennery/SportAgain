

<?php session_start();

echo 'ARRIVER SUR LA PAGE nom utilisateur est  '.$_SESSION['pseudo']; ?>