<link rel="stylesheet" href="../Vue/footer.css">
<footer style="padding-top:-100px">
            <div class="BasDePage">
            <center>
                <img src="../Vue/Image/initialefinish.png" class="picture"/>
            </center>
            <center>
            <table class="BasDePage3">
                <tr>
                    <td>
                       <a href="https://twitter.com/">
                           <img src="../Vue/Image/twitter.png" class="picture"/>
                       </a>
                    </td>
                    <td>
                       <a href="https://fr-fr.facebook.com/">
                           <img src="../Vue/Image/facebook.png" class="picture"/>
                        </a>
                    </td>
                    <td> 
                       <a href="https://plus.google.com/">
                           <img src="../Vue/Image/googleplus-logo.png" class="picture"/>
                        </a>
                    </td>
                </tr>
            </table>
            </center>
            <table class="BasdePage2">
             <tr>
                <td class="souligne"> 
                    Accueil 
                </td>
                <td> 
                    |
                </td>
                <td class="souligne">  
                    Sports
                </td>
                <td> 
                    |
                </td>
                <td class="souligne"> 
                    Qui sommes-nous ? 
                </td>
                <td> 
                    |
                </td>
                <td class="souligne"> 
                    Conditions d'utilisation
                </td>
            </tr>
        </table>
        </div>
</footer>