<html>
	<head>
        <link rel="stylesheet" href="FAQ.css">
        <meta charset="utf-8"/>
    </head>
 	<header>
		<?php include('../Controleur/choix_header.php'); ?>
	</header>	
	<body>
		<div id="faq">
		</div>
		<div>
			<h1 class="question">Decouvrir Sport Again</h1>
				<p class="reponse">Reponseeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeemmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm</p>
			<br>
			<h1 class="question">Question</h1>
				<p class="reponse">Reponse</p>
			<br>
			<h1 class="question">Question</h1>
				<p class="reponse">Reponse</p>
			<br>
			<h1 class="question">Question</h1>
				<p class="reponse">Reponse</p>
			<br>
			<h1 class="question">Question</h1>
				<p class="reponse">Reponse</p>
			<br>
			<h1 class="question">Question</h1>
				<p class="reponse">Reponse</p>
			<br>
			<h1 class="question">Question</h1>
				<p class="reponse">Reponse</p>
			<br>
		</div>	
	</body>
</html>