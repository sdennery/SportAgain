<html>
    <head>
        <link rel="stylesheet" href="profil_grope.css">
        <meta charset="utf-8"/>
    </head>
    <?php include("header_connecte.php")?>
    <body>
    <nav>
        <article id="article">
        <div class="article">
            <p class="art" id="planning"> Planning </p>
            <div id="fond"> 
            <span style="font-size:36px;color:white;margin-left:35%"> NOM DU GROUPE </span>
            </div>
            <p class="bordure"><span style="font-size:24px;margin-left:35%"> <strong>DESCRIPTION DU GROUPE </strong> </span></p>
            <p class="bordure"><span style="font-size:24px;margin-left:35%"> <strong>DISCUSSION EN LIGNE</strong> </span></p>
            <p class="bordure"><span style="font-size:24px;margin-left:35%"> <strong>MEMBRES DU GROUPE</strong> </span></p>
            <p> <span id="bouton" style="margin-left:590px"> <strong> Créer un évènement </strong></span> <span id="bouton" style="margin-left:30px"> <strong>Modifier la page </strong> </span>  <span id="bouton" style="margin-left:30px"> <strong>Supprimer le groupe </strong></span> </p>
            <p class="art" id="MesGroupes"> Mes groupes </p>
            <p class="art" id="AideEnLigne"> Aide en ligne </p>
            <br>
            <br>
            <?php include("footer.php"); ?>
        </div>
        </article>
    </nav>  
    </body>
</html>