-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Ven 10 Juin 2016 à 07:02
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `sport'again`
--

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) CHARACTER SET utf8 NOT NULL,
  `contenu` text CHARACTER SET utf8 NOT NULL,
  `date_post` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `club`
--

CREATE TABLE IF NOT EXISTS `club` (
  `id_club` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `Nom_proprietaire` varchar(50) NOT NULL,
  `adresse` varchar(100) NOT NULL,
  `Departement` int(101) NOT NULL,
  `sport` varchar(101) NOT NULL,
  `numero_club` int(11) NOT NULL,
  `telephone` int(11) NOT NULL,
  `descriptif` varchar(500) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `id_sport` int(11) NOT NULL,
  PRIMARY KEY (`id_club`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `commentaires`
--

CREATE TABLE IF NOT EXISTS `commentaires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_categorie` int(11) NOT NULL,
  `auteur` varchar(255) CHARACTER SET utf8 NOT NULL,
  `commentaire` text CHARACTER SET utf8 NOT NULL,
  `date_post` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `evenement`
--

CREATE TABLE IF NOT EXISTS `evenement` (
  `id_evenement` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `titre` varchar(50) NOT NULL,
  `lieu` varchar(50) NOT NULL,
  `horaire` datetime NOT NULL,
  `description` text,
  `nb_place` int(11) DEFAULT NULL,
  `sport` varchar(100) NOT NULL,
  PRIMARY KEY (`id_evenement`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `id_faq` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) NOT NULL,
  `reponse` varchar(255) NOT NULL,
  PRIMARY KEY (`id_faq`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `forum`
--

CREATE TABLE IF NOT EXISTS `forum` (
  `id_forum` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `Titre` varchar(50) NOT NULL,
  `Commentaire` text NOT NULL,
  `Date_post` datetime NOT NULL,
  `Sujet` varchar(255) NOT NULL,
  PRIMARY KEY (`id_forum`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `groupe`
--

CREATE TABLE IF NOT EXISTS `groupe` (
  `id_groupe` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `sport` varchar(255) NOT NULL,
  `nombre_place` int(11) DEFAULT NULL,
  `nombre_inscrit` int(11) DEFAULT NULL,
  `niveau` varchar(50) DEFAULT NULL,
  `etat` varchar(50) NOT NULL,
  `descriptif` varchar(900) DEFAULT NULL,
  `photo_groupe` varchar(100) DEFAULT NULL,
  `id_planning` smallint(5) unsigned NOT NULL,
  `id_utilisateur` smallint(5) unsigned NOT NULL,
  `departement` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  PRIMARY KEY (`id_groupe`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `inscrit_club`
--

CREATE TABLE IF NOT EXISTS `inscrit_club` (
  `id_inscrit_club` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `etat` varchar(50) NOT NULL,
  `date_demande` date NOT NULL,
  `date_inscrit` date NOT NULL,
  `id_club` smallint(5) unsigned NOT NULL,
  `id_utilisateur` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_inscrit_club`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `inscrit_groupe`
--

CREATE TABLE IF NOT EXISTS `inscrit_groupe` (
  `id_inscrit_groupe` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `etat` varchar(50) NOT NULL,
  `date_demande` date NOT NULL,
  `date_inscrit` date NOT NULL,
  `id_groupe` smallint(5) unsigned NOT NULL,
  `id_utilisateur` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_inscrit_groupe`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `message_club`
--

CREATE TABLE IF NOT EXISTS `message_club` (
  `id_message_club` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `horaire` datetime NOT NULL,
  `id_club` smallint(5) unsigned NOT NULL,
  `id_utilisateur` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_message_club`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `message_groupe`
--

CREATE TABLE IF NOT EXISTS `message_groupe` (
  `id_message_groupe` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `horaire` datetime NOT NULL,
  `id_groupe` smallint(5) unsigned NOT NULL,
  `id_utilisateur` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_message_groupe`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `note_club`
--

CREATE TABLE IF NOT EXISTS `note_club` (
  `id_note_club` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `note` int(11) NOT NULL,
  `id_club` smallint(5) unsigned NOT NULL,
  `id_utilisateur` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_note_club`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `participe_evenement`
--

CREATE TABLE IF NOT EXISTS `participe_evenement` (
  `id_participe_evenement` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_evenement` smallint(5) unsigned NOT NULL,
  `id_utilisateur` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_participe_evenement`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `planning`
--

CREATE TABLE IF NOT EXISTS `planning` (
  `id_planning` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_groupe` int(11) NOT NULL,
  `lieu` varchar(255) CHARACTER SET utf8 NOT NULL,
  `titre` varchar(255) CHARACTER SET utf8 NOT NULL,
  `date` date NOT NULL,
  `descriptif_event` varchar(255) NOT NULL,
  `sport` varchar(255) NOT NULL,
  PRIMARY KEY (`id_planning`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `rubrique_diverse`
--

CREATE TABLE IF NOT EXISTS `rubrique_diverse` (
  `id_rubrique_diverse` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `rubrique_diverse` varchar(50) NOT NULL,
  `id_forum` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_rubrique_diverse`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `rubrique_sport`
--

CREATE TABLE IF NOT EXISTS `rubrique_sport` (
  `id_rubrique_sport` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `rubrique_sport` varchar(50) NOT NULL,
  PRIMARY KEY (`id_rubrique_sport`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `sport`
--

CREATE TABLE IF NOT EXISTS `sport` (
  `id_sport` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `sport` varchar(50) NOT NULL,
  `id_rubrique_sport` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_sport`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id_utilisateur` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `nom_utilisateur` varchar(50) NOT NULL,
  `mot_de_passe` varchar(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `adresse` varchar(100) DEFAULT NULL,
  `departement` int(10) NOT NULL,
  `date_de_naissance` date DEFAULT NULL,
  `role` varchar(50) DEFAULT 'membre',
  `avatar` varchar(100) DEFAULT NULL,
  `id_forum` smallint(5) unsigned NOT NULL,
  `sport_favori` varchar(100) NOT NULL,
  PRIMARY KEY (`id_utilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur_groupe`
--

CREATE TABLE IF NOT EXISTS `utilisateur_groupe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_groupe` int(11) NOT NULL,
  `id_utilisateur` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `Etat` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `visualise_planning`
--

CREATE TABLE IF NOT EXISTS `visualise_planning` (
  `id_visualise_planning` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `id_planning` smallint(5) unsigned NOT NULL,
  `id_utilisateur` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`id_visualise_planning`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
